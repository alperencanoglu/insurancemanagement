namespace Infrastructure.Initializers;

public interface IDbInitializer
{
    
    public void Initialize();
}